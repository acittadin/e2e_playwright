import { Locator, Page, expect } from '@playwright/test';
import G1Elements from '../elements/G1Elements';
import BasePage from './BasePage';

export default class G1Page extends BasePage {
  readonly g1Elements: G1Elements;

  constructor(readonly page: Page) {
    super(page);
    this.page = page;
    this.g1Elements = new G1Elements(page);
  }

  private async safeClick(locator: Locator, timeout = 3000): Promise<boolean> {
    try {
      const element = locator.first();
      await element.scrollIntoViewIfNeeded();
      if (await element.isVisible({ timeout })) {
        await element.click({ timeout, force: true });
        return true;
      }
    } catch {
      return false;
    }

    return false;
  }

  async acessarPagina(): Promise<void> {
    try {
      await this.page.goto('https://g1.globo.com/sc/santa-catarina/', {
        waitUntil: 'commit',
        timeout: 30000
      });

      await this.page.waitForLoadState('domcontentloaded', { timeout: 15000 }).catch(() => {});
    } catch (error) {
      console.log('Ignorando lentidão extrema do G1 e forçando a continuação dos testes...');
    }
  }

  async fecharNotificacoes(): Promise<void> {
    const candidatos = [
      this.g1Elements.getBotaoAgoraNao(),
      this.page.getByRole('button', { name: /aceitar|continuar|prosseguir|fechar/i }).first(),
      this.page.getByText(/aceito|de acordo|agora não|fechar/i).first()
    ];

    for (const candidato of candidatos) {
      if (await this.safeClick(candidato, 3000)) {
        return;
      }
    }
  }

  async validarCarregamentoCabecalho(): Promise<void> {
    await expect(this.page).toHaveTitle(/santa catarina/i, { timeout: 30000 });
    await expect(this.g1Elements.getCabecalhoLogo()).toBeVisible({ timeout: 30000 });
  }

  async validarMancheteNaTela(): Promise<void> {
    await expect(this.g1Elements.getManchetePrincipal()).toBeVisible({ timeout: 30000 });
  }

  async pesquisarNoticia(termo: string): Promise<void> {
    const busca = this.g1Elements.getCampoBuscaInput();
    const lupa = this.g1Elements.getBotaoLupaBusca();

    if (await this.safeClick(lupa, 5000)) {
      await busca.waitFor({ state: 'visible', timeout: 15000 });
    }

    await busca.fill(termo, { timeout: 15000 });
    await busca.press('Enter');
  }

  async validarBusca(): Promise<void> {
    await expect(this.page).toHaveURL(/(busca|pesquisa)/i, { timeout: 30000 });
  }

  async abrirMenuLateral(): Promise<void> {
    const menu = this.g1Elements.getBotaoMenuLateral();
    await this.safeClick(menu, 5000);
  }

  async validarMenuAberto(): Promise<void> {
    await expect(this.g1Elements.getMenuLateralAberto()).toBeVisible({ timeout: 30000 });
  }

  async navegarParaRegiaoSul(): Promise<void> {
    const menu = this.g1Elements.getBotaoMenuLateral();
    await this.safeClick(menu, 5000);

    const regiao = this.g1Elements.getLinkRegiaoSul();
    await this.safeClick(regiao, 5000);

    await expect(this.page).toHaveURL(/sul.*santa.*catarina|sul.*sc/i, { timeout: 30000 });
  }
}