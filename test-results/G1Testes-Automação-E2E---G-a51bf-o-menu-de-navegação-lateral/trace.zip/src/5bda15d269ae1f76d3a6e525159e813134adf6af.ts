import { test } from '@playwright/test';
import G1Page from '../support/pages/G1Page';

test.describe('Automação E2E - G1 Santa Catarina', () => {
  let g1Page: G1Page;

  test.beforeEach(async ({ page }) => {
    g1Page = new G1Page(page);
    await g1Page.acessarPagina();
    await g1Page.fecharNotificacoes();
  });

  test('Teste 1: Deve carregar a página inicial e exibir o logótipo de SC', async () => {
    await g1Page.validarCarregamentoCabecalho();
  });

  test('Teste 2: Deve validar a visibilidade da manchete principal do dia', async () => {
    await g1Page.validarMancheteNaTela();
  });

  test('Teste 3: Deve realizar uma pesquisa por "Criciúma" com sucesso', async () => {
    await g1Page.pesquisarNoticia('Criciúma');
    await g1Page.validarBusca();
  });

  test('Teste 4: Deve abrir e exibir o menu de navegação lateral', async () => {
    await g1Page.abrirMenuLateral();
    await g1Page.validarMenuAberto();
  });

  test('Teste 5: Deve clicar na categoria e navegar para a Região Sul de SC', async () => {
    await g1Page.navegarParaRegiaoSul();
  });
});